package com.aiimageloader.model

data class CoverageModel(
    var id: String,
    var title: String,
    var thumbnail: ThumbnailModel,
)