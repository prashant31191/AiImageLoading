package com.aiimageloader.lib

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.aiimageloader.network.CheckNetwork
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors


interface RepositoryCallback<T> {
    fun onComplete(result: Result<T>?)
}


public class ImageRepository(context: Context) {
    internal var fileCache: FileCache
    internal var memoryCache = MemoryCache()
    var mContext: Context? = null

    var executorService = Executors.newFixedThreadPool(4)

    init {
        fileCache = FileCache(context)
        mContext = context
    }

    fun makeSynchronousRequest(url: String, callback: RepositoryCallback<Any>) {

        executorService.execute(Runnable {
            try {
                val result: Result<Any> = getResultFromUrl(url)
                callback.onComplete(result)
            } catch (e: Exception) {
                val errorResult: Result<Any> = Result.Error(e)
                callback.onComplete(errorResult)
            }
        })


    }

    fun getResultFromUrl(url: String): Result<Any> {
        try {
            val f = fileCache.getFile(url)

            val decodedBitmap= decodeFile(f)
            if (decodedBitmap != null)
                return Result.Success(decodedBitmap)

            val connectivityManager =
                mContext?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?

            if(connectivityManager !=null && CheckNetwork.getCurrentConnectivityState(connectivityManager) == CheckNetwork.NetworkConnectionState.Available){
                try {
                    var bitmap: Bitmap? = null
                    val imageUrl = URL(url)
                    val conn = imageUrl.openConnection() as HttpURLConnection
                    conn.connectTimeout = 3000
                    conn.readTimeout = 10000
                    conn.instanceFollowRedirects = true
                    val `is` = conn.inputStream
                    val os = FileOutputStream(f)
                    copyStream(`is`, os)
                    os.close()
                    conn.disconnect()
                    bitmap = decodeFile(f)

                    return Result.Success(bitmap)
                    //return bitmap
                } catch (ex: Throwable) {
                    ex.printStackTrace()
                    if (ex is OutOfMemoryError)
                        memoryCache.clear()

                    var ex = Exception("Loading Fail Exception")
                    return Result.Error(ex)
                    //return null
                }
            } else {
                var errNetwork = Exception("Network Error - UnknownHostException")
                return Result.Error(errNetwork)
            }

        } catch (e: Exception) {
            return Result.Error(e)
        }
    }

    private fun copyStream(`is`: InputStream, os: OutputStream) {
        val buffer_size = 1024
        try {
            val bytes = ByteArray(buffer_size)
            while (true) {
                val count = `is`.read(bytes, 0, buffer_size)
                if (count == -1)
                    break
                os.write(bytes, 0, count)
            }
        } catch (ex: Exception) {
        }

    }

    private fun decodeFile(f: File): Bitmap? {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            val stream1 = FileInputStream(f)
            BitmapFactory.decodeStream(stream1, null, o)
            stream1.close()

            val REQUIRED_SIZE = 140
            var width_tmp = o.outWidth
            var height_tmp = o.outHeight
            var scale = 1
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE || height_tmp / 2 < REQUIRED_SIZE)
                    break
                width_tmp /= 2
                height_tmp /= 2
                scale *= 2
            }

            val o2 = BitmapFactory.Options()
            o2.inSampleSize = scale
            val stream2 = FileInputStream(f)
            val bitmap = BitmapFactory.decodeStream(stream2, null, o2)
            stream2.close()
            return bitmap
        } catch (e: FileNotFoundException) {
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return null
    }





}
