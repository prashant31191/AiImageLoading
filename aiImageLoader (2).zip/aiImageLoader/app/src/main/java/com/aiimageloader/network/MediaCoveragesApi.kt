package com.aiimageloader.network


import com.aiimageloader.model.CoverageModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

public interface MediaCoveragesApi {

    // https://acharyaprashant.org/api/v2/content/misc/media-coverages?limit=100
    // https://acharyaprashant.org/api/v2/
    // content/misc/media-coverages
    // ?limit=100
    @Headers("Accept: application/json")
    @GET("content/misc/media-coverages")
    abstract fun getMediaCoveragesList(@Query("limit") limit: String): Call<ArrayList<CoverageModel>>
}