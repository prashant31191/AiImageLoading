package com.aiimageloader.ui.screen

import androidx.compose.runtime.MutableState
import androidx.lifecycle.ViewModel
import com.aiimageloader.model.CoverageModel
import com.aiimageloader.network.MediaCoveragesApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class HomeViewModel : ViewModel() {

    val API_BASE_URL = "https://acharyaprashant.org/api/v2/"

    val retrofit = Retrofit.Builder()
        .baseUrl(API_BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    fun callMediaCoveragesList(
        limit: String,
        listCoverage: MutableState<List<CoverageModel>>,
        isLoading: MutableState<Boolean>
    ) {
        isLoading.value = true
        val api = retrofit.create(MediaCoveragesApi::class.java)
        val call = api.getMediaCoveragesList(limit)
        call.enqueue(object : Callback<ArrayList<CoverageModel>> {
            override fun onResponse(
                call: Call<ArrayList<CoverageModel>>,
                response: Response<ArrayList<CoverageModel>>
            ) {
                if (response.isSuccessful)
                    listCoverage.value = response.body()!!

                isLoading.value = false
            }

            override fun onFailure(call: Call<ArrayList<CoverageModel>>, t: Throwable) {
                isLoading.value = false
            }
        })
    }
}