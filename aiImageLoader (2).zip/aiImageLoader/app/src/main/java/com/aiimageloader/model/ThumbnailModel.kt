package com.aiimageloader.model

data class ThumbnailModel(
    var id: String,
    var domain: String,
    var basePath: String,
    var key: String,
)