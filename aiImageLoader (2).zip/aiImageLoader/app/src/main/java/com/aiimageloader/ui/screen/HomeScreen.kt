package com.aiimageloader.ui.screen

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aiimageloader.lib.ImageRepository
import com.aiimageloader.model.CoverageModel
import com.aiimageloader.network.CheckNetwork
import com.aiimageloader.ui.theme.Purple700
import com.aiimageloader.ui.theme.Purple700_dark
import com.aiimageloader.ui.theme.Purple80
import com.aiimageloader.R.string as AppString

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(homeViewModel: HomeViewModel) {

    val context = LocalContext.current
    var mImageRepository = ImageRepository(context)

    val limit = remember {
        mutableStateOf(100)
    }

    val isLoading = remember {
        mutableStateOf(true)
    }

    val listMediaCoverages = remember {
        mutableStateOf(listOf<CoverageModel>())
    }

    // Api call to retrieve data
    homeViewModel.callMediaCoveragesList(
        limit = "" + limit.value,
        isLoading = isLoading,
        listCoverage = listMediaCoverages
    )

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text(
                    text = stringResource(AppString.app_name),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = Color.White,
                )
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Purple700_dark))
        },
        content = {
            Column(
                modifier = Modifier
                    .background(color = Color.White)
                    .padding(it)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                val connectivityManager =
                    context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager?

                if (connectivityManager != null && CheckNetwork.getCurrentConnectivityState(
                        connectivityManager
                    ) == CheckNetwork.NetworkConnectionState.Available
                ) {
                    if (listMediaCoverages.value.size <= 0) {
                        Text(text = stringResource(AppString.lbl_record_not_found), modifier = Modifier.padding(16.dp))
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3)
                        ) {
                            this.items(listMediaCoverages.value) { coverage ->
                                Column {
                                    var thmb = coverage.thumbnail
                                    var imageURL =
                                        thmb.domain + "/" + thmb.basePath + "/20/" + thmb.key // 40 : It's a thumbnail type size it's like 10,20,30,40 getting from api
                                    ImageLoadFromURL(imageURL, mImageRepository)
                                }
                            }

                            item {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Button(onClick = {
                                        var mLimit = limit.value.plus(25)
                                        limit.value = mLimit

                                        val callAPI = homeViewModel.callMediaCoveragesList(
                                            limit = "" + mLimit,
                                            isLoading = isLoading,
                                            listCoverage = listMediaCoverages
                                        )
                                    }, colors = ButtonDefaults.buttonColors(containerColor = Purple700_dark)) {
                                        Text(stringResource(AppString.lbl_load_more), color = Color.White)
                                    }

                                    if (isLoading.value) {
                                        CircularProgressIndicator(
                                            modifier = Modifier
                                                .width(46.dp)
                                                .padding(start = 8.dp),
                                            color = Purple700,
                                            trackColor = Purple80,
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {

                    Text(
                        text = stringResource(AppString.msg_network_err),
                        modifier = Modifier.padding(16.dp)
                    )

                    Button(onClick = {
                        var mLimit = limit.value.plus(25)
                        limit.value = mLimit

                        homeViewModel.callMediaCoveragesList(
                            limit = "" + mLimit,
                            isLoading = isLoading,
                            listCoverage = listMediaCoverages
                        )
                    }, colors = ButtonDefaults.buttonColors(containerColor = Purple700_dark)

                        ) {
                        Text(stringResource(AppString.lbl_load_more), color = Color.White)
                    }

                }
            }
        }
    )
}

